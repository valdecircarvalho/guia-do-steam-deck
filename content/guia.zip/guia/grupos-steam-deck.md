---
title: 'Grupos sobre o Stem Deck'
date: 2023-03-01T00:00:00+00:00
weight: 9
summary: 'Grupos Facebook, Telegram e WhatsApp sobre o Steam Deck para você se socializar e conhecer outras pessoas interessadas em Steam Deck'
---

### Grupos Telegram

 - #### Português
    - [Steam Deck Brazil](https://www.facebook.com/groups/steamdeckbrazil/)
    - [Valve Steam Deck Brasil](https://www.facebook.com/groups/valvesteamdeckbrasil/)

- #### Inglês
    - [SteamDeck Tips Tricks Hacks & Emulation](https://www.facebook.com/groups/895343947759775)
    - [Steam Deck Windows10/11 Community](https://www.facebook.com/groups/1857754067746453/)
    - [Steam Deck Community](https://www.facebook.com/groups/steamdeckgamers/)
    - [Steam Deck](https://www.facebook.com/groups/steamdeck/)


### Grupos Telegram
- [Steam Deck BR 🇧🇷](https://t.me/+53kVjmn5GDBjM2Yx)
- [Steam Deck Brasil 🇧🇷](https://t.me/SteamDeckBr)

### Grupos WhatsApp
