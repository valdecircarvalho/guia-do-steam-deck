---
title: 'Sites e Blogs sobre o Steam Deck'
date: 2023-03-01T00:00:00+00:00
weight: 12
summary: 'Sites e Blogs sobre o Steam Deck'
---

- [steamdeckhq.com](https://steamdeckhq.com/)
- [steamdecklife.com](https://steamdecklife.com/)
- [overkill.wtf](https://overkill.wtf/tag/steam-deck/)

----
## Outro Sites sobre o Steam Deck
- [Awesome Steam Deck by @matthewbarreiro](https://github.com/matthewbarreiro/awesome-steam-deck)
- [Awesome Steam Deck by @mikeroyal](https://github.com/mikeroyal/Steam-Deck-Guide)
- [GamingOnLinux](https://www.gamingonlinux.com/) - Cobertura de jogos de Linux em geral, com foco especial no Steam Deck.
- [Boiling Steam](https://boilingsteam.com/) - Cobertura de jogos de Linux em geral, com foco especial no Steam Deck.
- [ProtonDB](https://www.protondb.com/) - Banco de dados colaborativo de relatórios de compatibilidade de jogos para Linux e Steam Deck.
- [sharedeck.games - An unofficial site to find and share Steam Deck performance configurations.](https://sharedeck.games/)
- [Linux Gaming Central](https://www.linuxgamecast.com/category/news/) - Notícias sobre jogos para Linux, incluindo notícias do Steam Deck.
