# Steam Deck - Software Info & Troubleshooting Guide
Fonte: https://help.steampowered.com/en/faqs/view/7DD4-C618-182E-0E49