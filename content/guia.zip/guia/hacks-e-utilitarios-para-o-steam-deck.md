---
title: 'Steam Deck Hacks & Utilitários'
date: 2023-03-01T00:00:00+00:00
weight: 21
summary: 'Steam Deck Hacks & Utilitários'
---

**_Em construção_**

  - **Stream Deck Cleaner** - Remove arquivos cache antigos do seu Steam Deck e recupera espaço no SSD. <sup>artigo e tradução em andamento</sup>
    - [https://arodznegron.medium.com/steam-deck-save-internal-space-with-this-script-f45e31f10830](https://arodznegron.medium.com/steam-deck-save-internal-space-with-this-script-f45e31f10830)
    - [https://steamdecklife.com/2022/09/23/delete-your-shader-cache-folder-with-this-steam-deck-script/](https://steamdecklife.com/2022/09/23/delete-your-shader-cache-folder-with-this-steam-deck-script/)
    - [https://linuxgamingcentral.com/posts/deckcleaner/](https://linuxgamingcentral.com/posts/deckcleaner/)
    - [https://github.com/scawp/Steam-Deck.Shader-Cache-Killer](https://github.com/scawp/Steam-Deck.Shader-Cache-Killer)
  