---
title: 'Qual modelo comprar?'
date: 2023-03-01T00:00:00+00:00
weight: 4
summary: 'Qual modelo de Steam Deck devo comprar?'
---

Esse é um grande debate. Se você fizer as contas, comprar o modelo de 64GB + SSD 1Tb para fazer o upgrade pode sair mais barato, mas ai vai de você querer passar pelo trabalho de fazer a troca, etc. 

> Eu comprei o modelo de 64GB justamente por causa disso, mas após um tempo com o Deck, ainda não fiz o upgrade, porque sei que vou lotar de jogos que não vou jogar. Mas ainda quero fazer o upgrade, principalmente pelo emuladores.