---
title: 'Como instalar jogos "Não-Steam" no Steam Deck'
date: 2023-03-01T00:00:00+00:00
weight: 16
summary: 'Como instalar jogos "Não-Steam" no Steam Deck'
---

**_Em construção_**

- [How to install Epic and GOG games on Steam Deck](https://www.dexerto.com/tech/how-to-install-epic-games-on-steam-deck-1894333/)
- [How to play Battle.net games on Steam Deck](https://www.dexerto.com/tech/how-to-play-battle-net-games-on-steam-deck-2023706/)
- [How to play Xbox and PC Game Pass games on Steam Deck](https://www.dexerto.com/tech/game-pass-on-steam-deck-1896451/)
- [How to play Amazon Prime games on Steam Deck](https://www.dexerto.com/tech/how-to-play-amazon-prime-games-on-steam-deck-1931049/)
