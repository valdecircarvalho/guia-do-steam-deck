---
title: 'O Guia Descomplicado de ROMsets para Emudeck - Parte 2'
date: 2023-03-01T00:00:00+00:00
weight: 33
summary: 'O Guia descomplicado do Emudeck - Parte 2 - Nesse guia, iremos falar sobre todos os detalhes sobre o uso do Emudeck no Steam Deck'
---

> Esse guia em 3 partes foi traduzido e adaptado dos textos publicado no Reddit pelo usuário [/u/EmulationStranger](https://www.reddit.com/user/EmulationStranger/) com algumas modificações e adições para o público brasileiro. Os posts originais estão [aqui](https://www.reddit.com/user/EmulationStranger/comments/11kom88/idiots_guide_to_steam_rom_manager_for_emudeck/), [aqui](https://www.reddit.com/r/SteamDeckEmulation/comments/11kcrhf/idiots_guide_to_romsets_for_emudeck/) e [aqui](https://www.reddit.com/user/EmulationStranger/comments/11j09qc/idiots_guide_to_emudeck_where_to_find_bios_and/)


### Parte 3 - O Guia descomplicado do Emudeck
**_Em construção_**