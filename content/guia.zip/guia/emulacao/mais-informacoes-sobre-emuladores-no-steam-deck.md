---
title: 'Mais informações sobre emulação no Steam Deck'
date: 2023-03-01T00:00:00+00:00
weight: 35
summary: 'Mais informações sobre emulação no Steam Deck'
---

## Mais sobre emulação
**_Em construção_**
  - ### Nintendo Switch
  - ### Nintendo Wii U
  - ### Nintendo Wi
  - ### Nintendo 3DS
  - ### Microsoft Xbox 360
  - ### Microsoft Xbox
  - ### Sony Playstation 3
  - ### Sony Playstation 2
  - ### Sony Playstation 2
  - ### Sony PSP
  - ### Sony Playstation Vita
  - ### Android