---
title: 'O Steam Deck no Brasil'
date: 2023-03-01T00:00:00+00:00
weight: 3
summary: 'O Steam Deck no Brasil'
---

O Steam Deck **ainda não é oficialmente vendido pela Valve no Brasil**, mas não é por isso que você não vai conseguir comprar o seu. 

No Brasil você irá conseguir comprar o seu Deck no Mercado Livre, AliExpress e também algumas lojas de games. 

O Google é o seu melhor amigo. Em alguns grupoos do Facebook você irá encontrar pessoas vendendo Steam Deck por valores variados.

Outra forma de conseguir o seu é via importação direta, um amigo que está por lá, empresas de redirecionamento, etc. 

Comprando aqui no Brasil, espere pagar entre R$3500-R$4500 no modelo 64GB e até uns R$6000 no modelo 512GB. 
