# Controles
Dicas sobre a configuração dos controles do Steam Deck.

- Básico
- Configurações avançadas
- Configurações de jogos
- Remapeamento dos controles e botões
- Customização dos controles

+ https://steamcommunity.com/sharedfiles/filedetails/?id=2804823261
+ https://sortatechy.com/remapping-gaming-controls-steam-deck/
+ https://www.digitaltrends.com/computing/how-to-customize-controls-on-the-steam-deck/
+ https://www.pcworld.com/article/1364387/the-steam-decks-button-mapper-is-the-best-feature-youre-not-using.html
+ https://www.tomsguide.com/how-to/how-to-customize-your-controller-layout-on-the-steam-deck
+ https://www.lifewire.com/use-external-controllers-on-steam-deck-6544100
+ https://www.lifewire.com/connect-mouse-and-keyboard-to-steam-deck-6544106