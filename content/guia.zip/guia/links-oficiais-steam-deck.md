---
title: 'Links Oficiais'
date: 2023-03-01T00:00:00+00:00
weight: 7
summary: 'Sites e Links Oficiais sobre o Steam Deck'
---

### Português Brasil
- [Página Oficial do Steam Deck](https://www.steamdeck.com/pt-br/)
- [Hardware](https://www.steamdeck.com/pt-br/hardware)
- [Software](https://www.steamdeck.com/pt-br/software)
- [Jogos Steam Verificados](https://www.steamdeck.com/pt-br/verified)
- [Steam Deck Oficial Dock](https://www.steamdeck.com/pt-br/dock)
- [Tech Specs](https://www.steamdeck.com/pt-br/tech)
- [Novidades](https://www.steamdeck.com/pt-br/news)
- [FAQ - Perguntas Frequentes](https://www.steamdeck.com/pt-br/faq)
- [Press Kit](https://www.steamdeck.com/pt-br/press)
  
### Inglês
- [Página Oficial do Steam Deck](https://www.steamdeck.com/en/)
- [Hardware](https://www.steamdeck.com/en/hardware)
- [Software](https://www.steamdeck.com/en/software)
- [Jogos Steam Verificados](https://www.steamdeck.com/en/verified)
- [Steam Deck Oficial Dock](https://www.steamdeck.com/en/dock)
- [Tech Specs](https://www.steamdeck.com/en/tech)
- [Novidades](https://www.steamdeck.com/en/news)
- [FAQ - Perguntas Frequentes](https://www.steamdeck.com/en/faq)
- [Anúncio do Steam Deck no blog da Valve](https://store.steampowered.com/news/app/1406830/view/3070948040413601109)
- [Press Kit](https://www.steamdeck.com/en/press)

