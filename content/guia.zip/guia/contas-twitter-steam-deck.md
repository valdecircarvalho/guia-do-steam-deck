---
title: 'Redes Sociais - Twitter'
date: 2023-03-01T00:00:00+00:00
weight: 8
summary: 'Redes Sociais do Steam Deck - Twitter'
---

As contas abaixo são uma excelente fonte de informações sobre novidades, dicas e atualizações sobre o Steam Deck. 

### Twitter
- [Steam Deck Pals - Twitter List](https://twitter.com/i/lists/1637924098255777793)
- [@ondeck - Conta Oficial Valve](https://mobile.twitter.com/ondeck)
- [@ondeckupdates - Conta Oficial - Updates Steam Deck](https://twitter.com/ondeckupdates)
- [@SteamDeckHQ](https://twitter.com/SteamDeckHQ)
- [@SteamDeckFans](https://twitter.com/SteamDeckFans)
- [@SteamDeckGaming](https://twitter.com/SteamDeckGaming)
- [@SteamDeckLife](https://twitter.com/SteamDeckLife)
- [@SteamDeckEnergy](https://twitter.com/SteamDeckEnergy)
- [@OnDeck_News](https://twitter.com/OnDeck_News)
- [@SteamDecked](https://twitter.com/SteamDecked)
- [@Steamdeckreview](https://twitter.com/Steamdeckreview)
- [@SteamDeckBrasil](https://twitter.com/SteamDeckBrasil)
- [@TDeckverse](https://twitter.com/TDeckverse)
- [@ondeckpatrol](https://twitter.com/ondeckpatrol)
- [@linuxgamingctr](https://twitter.com/linuxgamingctr)
- [@The_SteamDeck](https://twitter.com/The_SteamDeck)


Mais algumas contas no Twitter que vale a pena seguir e que falam sobre Steam Deck - mas não exclusivamente. Essas contas todas falam apenas em Inglês.

- [@HiTechLoLife1](https://twitter.com/HiTechLoLife1)
- [@carygolomb](https://twitter.com/@carygolomb)
- [@RetroGameCorps](https://twitter.com/@RetroGameCorps)
- [@fanthedeck](https://twitter.com/@fanthedeck)
- [@theterk](https://twitter.com/@theterk)
- [@xylappen](https://twitter.com/@xylappen)
- [@MekelKasanova](https://twitter.com/@MekelKasanova)
- [@CryoByte33](https://twitter.com/@CryoByte33)
- [@deckwizardyt](https://twitter.com/@deckwizardyt)
- [@NerdNestTV](https://twitter.com/@NerdNestTV)
- [@staydeckready](https://twitter.com/@staydeckready)
- [@SDeckChecker](https://twitter.com/@SDeckChecker)

> Agora me ajudem com contas em Português que falam sobre Steam Deck.

