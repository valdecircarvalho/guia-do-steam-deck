---
title: 'Primeiros Passos com o seu novo Steam Deck'
date: 2024-03-01T00:00:00+00:00
weight: 19
summary: 'Primeiros Passos com o seu novo Steam Deck'
---

## Primeiros Passos com o seu novo Steam Deck
**_Em construção_**
  - Perguntas Frequentes - FAQ
  - Uso básico e solução de problemas
  - Software e solução de problemas
  - Modo Desktop
  - Configuração de Controles
  - Controles
