---
title: 'Windows no Steam Deck'
date: 2023-03-01T00:00:00-00:00
weight: 20
summary: 'Tudo sobre como instalar e usar o Windows no seu Steam Deck'
---

**_Em construção_**

- [Steam Deck Ultimate Windows Guide](https://baldsealion.github.io/Steam-Deck-Ultimate-Windows-Guide/)


Outros links (falta organizar)

- [https://www.dexerto.com/tech/install-windows-steam-deck-1970155/](https://www.dexerto.com/tech/install-windows-steam-deck-1970155/)

- [https://gamerant.com/guide-install-windows-steam-deck/](https://gamerant.com/guide-install-windows-steam-deck/)

- [https://www.digitaltrends.com/computing/how-to-install-windows-steam-deck/](https://www.digitaltrends.com/computing/how-to-install-windows-steam-deck/)

- [https://wagnerstechtalk.com/sd-windows/](https://wagnerstechtalk.com/sd-windows/)

- [https://www.thegamer.com/steam-deck-windows-how-to-install-guide/](https://www.thegamer.com/steam-deck-windows-how-to-install-guide/)

- [https://steamdeckhq.com/tips-and-guides/install-windows-10-11-on-steam-deck/](https://steamdeckhq.com/tips-and-guides/install-windows-10-11-on-steam-deck/)

- [https://store.steampowered.com/news/app/1675200/view/3131696199122435099](https://store.steampowered.com/news/app/1675200/view/3131696199122435099)

- [https://help.steampowered.com/en/faqs/view/6121-eccd-d643-baa8](https://help.steampowered.com/en/faqs/view/6121-eccd-d643-baa8)
  
- [https://www.reddit.com/r/SteamDeck/comments/vbpjoc/windows_11_tips_and_tricks_debloat_os_40hz_screen/](https://www.reddit.com/r/SteamDeck/comments/vbpjoc/windows_11_tips_and_tricks_debloat_os_40hz_screen/)