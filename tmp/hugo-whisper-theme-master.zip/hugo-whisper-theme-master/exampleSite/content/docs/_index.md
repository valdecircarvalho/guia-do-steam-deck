---
title: 'Overview'
date: 2018-11-28T15:14:39+10:00
weight: 1
---

## Whisper Theme

Whisper is a minimal documentation theme for Hugo. The design and functionality is intentionally minimal. We’re aiming for a similar feel to a Github readme.
